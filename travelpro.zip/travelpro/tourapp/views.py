from django.shortcuts import render

# Create your views here.
def demo(request):
    print(request.path)
    return render(request,'index.html')